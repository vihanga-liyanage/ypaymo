<html>
	<head>
		<title>My Form</title>
	</head>
	<body>
		<style>
			.error {color: #FF0000;}
		</style>
		<h3>Your form was successfully submitted!</h3>

		<p><?php echo anchor('form', 'Try it again!'); ?></p>

	</body>
</html>