<div class="main">
    <div class="content">
    	<div class="section group">
			<div class="col span_2_of_3 form-box">
			  	<div class="contact-form">
					<h3>Welcome Admin!</h3>
					<span><?php echo anchor('category', 'Manage Categories'); ?></span>
					<span><?php echo anchor('subcategory', 'Manage Sub Categories'); ?></span>
					<span><?php echo anchor('product', 'Manage Products'); ?></span>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>